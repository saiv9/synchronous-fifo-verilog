# LinkedIn project details

Use this after running the testbench, reviewing the waveforms, and making sure you can explain the design decisions.

## Project entry

**Title:** Parameterized Synchronous FIFO Design using Verilog HDL

**Description:** Designed a single-clock FIFO with configurable data width and depth. The RTL includes read and write pointers, occupancy tracking, full/empty status flags, pointer wrap-around, and protection against invalid read and write requests. A self-checking testbench compares the RTL behavior with a reference model and covers normal operation, boundary conditions, and simultaneous read/write requests.

**Skills:** Verilog HDL · RTL Design · Digital Logic Design · FIFO Architecture · Functional Verification · Icarus Verilog · GTKWave

**Project URL:** `https://github.com/YOUR_GITHUB_USERNAME/synchronous-fifo-verilog`

## Post draft

I have been working on a synchronous FIFO design in Verilog HDL as part of my digital design practice.

The FIFO has configurable data width and depth, separate read and write pointers, full and empty flags, and an occupancy counter. I also added protection for read requests when the FIFO is empty and write requests when it is full.

For verification, I prepared a self-checking testbench with a reference model. It checks FIFO ordering, boundary conditions, simultaneous read/write requests, and pointer wrap-around. The test script runs two depth configurations, including a non-power-of-two depth.

One detail I paid attention to was pointer wrap-around: the write and read pointers return to zero at `DEPTH - 1`, so the same RTL also handles a depth of 5 instead of depending on a power-of-two depth. Building the reference model made it easier to check the FIFO order cycle by cycle.

**Project repository:** [Add your GitHub repository link]

#VLSI #VerilogHDL #RTLDesign #DigitalDesign #ECE

## Before posting

- Run `scripts/run_sim.sh` or `scripts\run_sim.bat` and confirm both configurations print `PASS`.
- Open the VCD files in GTKWave and capture one readable waveform showing a write, a read, and the full/empty transitions.
- Replace `YOUR_GITHUB_USERNAME` with your GitHub username.
- Add the actual repository link to the post.
- Be ready to explain the reset behavior, accepted read/write conditions, and simultaneous read/write case.
