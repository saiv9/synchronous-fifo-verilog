#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if ! command -v iverilog >/dev/null 2>&1 || ! command -v vvp >/dev/null 2>&1; then
    echo "Error: Icarus Verilog is required. Install iverilog and vvp, then run this script again." >&2
    exit 1
fi

mkdir -p build

for depth in 8 5; do
    echo "==> Compiling FIFO test (depth=${depth})"
    iverilog -g2012 -Wall -s tb_sync_fifo \
        -Ptb_sync_fifo.FIFO_DEPTH="${depth}" \
        -o "build/tb_sync_fifo_${depth}" \
        rtl/sync_fifo.v tb/tb_sync_fifo.v

    echo "==> Running FIFO test (depth=${depth})"
    vvp "build/tb_sync_fifo_${depth}" "+VCD=build/sync_fifo_depth${depth}.vcd"
done

echo "Simulation runs completed. Waveforms are in build/."
