@echo off
setlocal
cd /d "%~dp0\.."
if not exist build mkdir build

where iverilog >nul 2>nul || (echo Icarus Verilog is required. Install iverilog and vvp. & exit /b 1)
where vvp >nul 2>nul || (echo Icarus Verilog runtime vvp was not found. & exit /b 1)

for %%D in (8 5) do (
  echo Compiling FIFO test with depth %%D
  iverilog -g2012 -Wall -s tb_sync_fifo -Ptb_sync_fifo.FIFO_DEPTH=%%D -o build\tb_sync_fifo_%%D rtl\sync_fifo.v tb\tb_sync_fifo.v || exit /b 1
  echo Running FIFO test with depth %%D
  vvp build\tb_sync_fifo_%%D +VCD=build/sync_fifo_depth%%D.vcd || exit /b 1
)

echo Simulation runs completed. Waveforms are in build\.
endlocal
